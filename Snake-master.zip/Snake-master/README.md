# Snake - Multi Control


This is a different take on classic snake game. This app allows you to chose from multiple ways to control your snake. 


## Controls

This app currently allows you two control schemes.

### Pov 

Turn the snake left or right relative to the direction snake is moving. For eg. If snake is moving East then turning left will move the snake to North.

You tap on left side of screen to turn left.

### Dual

This control uses left tap to move snake in West and South direction i.e.(left and down) and right tap to move snake to North and East  direction i.e.(up and right).

For eg. If snake is moving West then tapping left will move the snake to South. If snake is moving North then tapping left will move the snake to West. 

